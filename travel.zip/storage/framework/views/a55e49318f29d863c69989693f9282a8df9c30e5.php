<?php $__env->startSection('pageTitle'); ?> News Content <?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<div class="page-header page-header-default">
    <div class="breadcrumb-line">
        <ul class="breadcrumb">
            <li><a href="index.html"><i class="icon-home2 position-left"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="panel panel-flat">
    <div class="panel-heading">
        <h5 class="panel-title">Category
        <a href="<?php echo e(route('admin.news.blog')); ?>" class="btn btn-info"><i class=" icon-file-eye mr-2"></i>View</a>
        </h5>
        <div class="heading-elements">
            <ul class="icons-list">
                <li><a data-action="collapse"></a></li>
                <li><a data-action="reload"></a></li>
                <li><a data-action="close"></a></li>
            </ul>
        </div>
    </div>
    <div class="panel-body">
        <form role="form" action="<?php echo e(route('admin.news.blog.upadte')); ?>" method="post" enctype="multipart/form-data" id="news_editForm">
        <input type="hidden" name="id" value="<?php echo e($news->id); ?>">
            <div class="row">

                <div class="col-md-12">
                    <div class="form-group">
                        <label>News Title:</label>
                        <input type="text" name="title" id="title" class="form-control" placeholder="News Title" value="<?php echo e($news->title); ?>">
                    </div>
                </div>

                   <div class="col-md-12">
                    <div class="form-group">
                        <label>Short Content:</label>
                        <textarea rows="5" cols="5" class="form-control" name="short_content" id="short_content" placeholder="Short Content" style="resize: none;"><?php echo e($news->short_content); ?></textarea>
                    </div>
                </div>
                </div>
                <div class="row">
                       <div>
                         <?php if($news && isset($news->banner)): ?>
                            <img src="<?php echo e(asset('/storage/news/banner/'.$news->banner)); ?>" alt="" width="120px">
                         <?php endif; ?>
                    </div>
                            
                 <div class="col-md-6">
                    <div class="form-group">
                        <label>Banner:</label>
                        <input type="file" name="banner">

                         <?php if($news && isset($news->banner)): ?>
                         <input type="hidden" name="oldbanner" value="<?php echo e($news->banner); ?>">
                        <?php endif; ?>
                    </div>
                </div>

                 <div class="col-md-6">
                  <div>
                         <?php if($news && isset($news->photo)): ?>
                            <img src="<?php echo e(asset('/storage/news/photo/'.$news->photo)); ?>" alt="" width="120px">
                         <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label>Photo:</label>
                        <input type="file" name="photo">
                         <?php if($news && isset($news->photo)): ?>
                         <input type="hidden" name="oldphoto" value="<?php echo e($news->photo); ?>">
                        <?php endif; ?>
                    </div>
                </div>
                </div>

              <div class="row">
                 <div class="col-md-4">
                    <div class="form-group">
                        <label>Category:</label>
                        <select name="category_id" id="category_id" class="form-control select">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($news->category_id==$category->id?"selected":''); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                 <div class="col-md-4">
                    <div class="form-group">
                        <label>Comment:</label>
                        <select name="comment" id="comment" class="form-control select">
                            <option <?php echo e($news->comment ==1?"selected":''); ?> value="1">On</option>
                            <option <?php echo e($news->comment ==0?"selected":''); ?> value="0">Off</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Date:</label>
                      <input type="date" name="date" class="form-control" value="<?php echo e($news->date); ?>">
                    </div>
                </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                      <label>News Content:</label>
                        <textarea rows="5" cols="5" class="form-control summernote" name="news_content" id="news_content" style="resize: none;"><?php echo e($news->news_content); ?></textarea>
                    </div>
                </div>

                    <div class="row">
                         <h4>SEO Information</h4>
                            <div class="col-md-6">
                            <div class="form-group">
                                <label>Meta Title:</label>
                                <input type="text" name="meta_title" id="meta_title" class="form-control" placeholder="Meta Title" value="<?php echo e($news->meta_title); ?>">

                            </div>
                            </div>
                             <div class="col-md-6">
                                <div class="form-group">
                                <label>Meta Keywords:</label>
                                <input type="text" name="meta_keywords" id="meta_keywords" class="form-control" placeholder="Keywords" value="<?php echo e($news->meta_keywords); ?>">

                               </div>
                             </div> 
                       </div>
                      <div class="row">
                         <div class="col-md-12">
                            <div class="form-group">
                            <label>Meta Description:</label>
                            <textarea rows="5" cols="5" class="form-control " name="meta_description" id="meta_description" style="resize: none;" placeholder="Meta Description"><?php echo e($news->mets_description); ?></textarea>
                        </div>
                         </div>
                     </div>


            <div class="text-right">
                <button type="submit" class="btn btn-primary"  id="submit">Update News<i class="icon-arrow-right14 position-right"></i></button>
                <button type="button" class="btn btn-link" id="submiting" style="display: none;">Processing <img src="<?php echo e(asset('ajaxloader.gif')); ?>" width="80px"></button>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/editors/summernote/summernote.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/forms/styling/uniform.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/demo_pages/editor_summernote.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/demo_pages/form_checkboxes_radios.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/notifications/sweet_alert.min.js')); ?>"></script>

<script src="<?php echo e(asset('backend/assets/js/news.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>