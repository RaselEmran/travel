<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <title><?php echo $__env->yieldContent('pageTitle'); ?></title>
      <!-- Favicon png -->
    <link rel="shortcut icon" href="<?php if(isset($appSettings['bussiness_settings']) & isset($appSettings['bussiness_settings']['favicon'])): ?><?php echo e(asset('storage/logo/'.$appSettings['bussiness_settings']['favicon'])); ?> <?php else: ?><?php echo e(asset('image/favicon.png')); ?><?php endif; ?>">
    <!-- Global stylesheets -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('backend/global_assets/css/icons/icomoon/styles.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('backend/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('backend/assets/css/core.min.css')); ?>" rel="stylesheet" type="text/css">
     <link href="<?php echo e(asset('backend/assets/css/calulator.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('backend/assets/css/components.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('backend/assets/css/colors.min.css')); ?>" rel="stylesheet" type="text/css">
      <?php echo $__env->yieldPushContent('css'); ?>
    <!-- /global stylesheets -->


    <!-- /theme JS files -->

</head>

<body>

<?php echo $__env->make('admin.partail.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <!-- Page container -->
    <div class="page-container">

        <!-- Page content -->
        <div class="page-content">

            <!-- Main sidebar -->
        <?php echo $__env->make('admin.partail.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /main sidebar -->


            <!-- Main content -->
            <div class="content-wrapper">

                <!-- Page header -->
             <?php echo $__env->yieldContent('page-header'); ?>
                <!-- /page header -->


                <!-- Content area -->
                <div class="content">
                <?php $__env->startSection('content'); ?>
                <?php echo $__env->yieldSection(); ?>
                </div>
                <!-- /content area -->
                 <?php echo $__env->make('admin.partail.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <!-- /main content -->

        </div>
        <!-- /page content -->

    </div>
    <!-- /page container -->
    <!-- Core JS files -->
    <script src="<?php echo e(asset('backend/global_assets/js/plugins/loaders/pace.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/global_assets/js/core/libraries/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/global_assets/js/core/libraries/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/global_assets/js/plugins/loaders/blockui.min.js')); ?>"></script>
    <!-- /core JS files -->

    <!-- Theme JS files -->
    <script src="<?php echo e(asset('backend/global_assets/js/plugins/visualization/d3/d3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/global_assets/js/plugins/visualization/d3/d3_tooltip.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/global_assets/js/plugins/forms/styling/switchery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/global_assets/js/plugins/forms/selects/bootstrap_multiselect.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/global_assets/js/plugins/ui/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/global_assets/js/plugins/pickers/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/notifications/noty.min.js')); ?>"></script>

    <script src="<?php echo e(asset('backend/assets/js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/accounting.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/common.js')); ?>"></script>
    
    <script>
         $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

    </script>
    <script src="<?php echo e(asset('js/logout.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>
