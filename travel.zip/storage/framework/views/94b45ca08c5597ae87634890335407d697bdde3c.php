<tr>
    <td >
         <input type="time" name="time2[]" id="time2" class="form-control" placeholder="Itinary Date">  
     </td>
     <td >
          <input type="text" name="itinary_name2[]" id="itinary_name2" class="form-control" placeholder="Itinary Name">  
     </td>
     <td>
         <button type="button" class="btn btn-danger btn-xs remove2">-</button>
     </td>
 </tr>