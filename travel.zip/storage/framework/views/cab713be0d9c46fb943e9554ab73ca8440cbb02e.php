<tr>
    <td >
         <input type="time" name="time1[]" id="time1" class="form-control" placeholder="Itinary Date">  
     </td>
     <td >
          <input type="text" name="itinary_name1[]" id="itinary_name1" class="form-control" placeholder="Itinary Name">  
     </td>
     <td>
         <button type="button" class="btn btn-danger btn-xs remove1">-</button>
     </td>
 </tr>