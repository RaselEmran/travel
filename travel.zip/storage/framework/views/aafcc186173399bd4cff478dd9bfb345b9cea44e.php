<?php $__env->startSection('pageTitle'); ?> Hotel <?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<div class="page-header page-header-default">
    <div class="breadcrumb-line">
        <ul class="breadcrumb">
            <li><a href="index.html"><i class="icon-home2 position-left"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="panel panel-flat">
    <div class="panel-heading">
        <h5 class="panel-title">Hotel
        <a href="<?php echo e(route('admin.hotel.create')); ?>" class="btn btn-info"><i class="icon-stack-plus mr-2"></i>Creat</a>
        </h5>
        <div class="heading-elements">
            <ul class="icons-list">
                <li><a data-action="collapse"></a></li>
                <li><a data-action="reload"></a></li>
                <li><a data-action="close"></a></li>
            </ul>
        </div>
    </div>
    <div class="panel-body">
        <div class="table-responsive">
            <table class="table datatable-button-init-basic">
                <thead>
                    <tr>
                        <th>SL</th>
                        <th>Photo</th>
                        <th>Hotel Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="product_list">
                    <?php $__currentLoopData = $hotel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index+1); ?></td>
                        <td><img class="img-responsive img-thumbnail" src="<?php echo e(asset('/storage/hotel/photo/'.$element->photo)); ?>" alt="" width="120px"></td>
                        <td><?php echo e($element->name); ?></td>
                        <td>
                            <a href="#" class="btn btn-success" data-toggle="modal" data-target="#modal_default"  id="view_details" data-url="<?php echo e(route('admin.hotel.view',$element->id)); ?>"><i class=" icon-eye8"></i>View</a>
                            <a href="<?php echo e(route('admin.hotel.edit',$element->id)); ?>" class="btn btn-info"><i class=" icon-pencil5"></i>Edit</a>
                            <a href="#" id="delete_item" data-id="<?php echo e($element->id); ?>" data-url="<?php echo e(route('admin.hotel.delete',$element->id)); ?>" class="btn btn-danger"><i class="  icon-trash"></i>Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="modal_default" data-backdrop="static" class="modal fade" tabindex="-1">
    <div class="modal-dialog modal-full">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h5 class="modal-title">Hotel View</h5>
            </div>
            <div class="modal-body" id="show">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/tables/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/tables/datatables/extensions/buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/demo_pages/datatables_extension_buttons_init.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/demo_pages/form_checkboxes_radios.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/notifications/sweet_alert.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/hotel.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>