<?php $__env->startSection('pageTitle'); ?> dashboard <?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('page-header'); ?>
		<img src="<?php echo e(asset('fontend/images/bg8.jpg')); ?>" class="bg1"/>
                    
           
     
            <div class="middle-right titleimg">

            <h2><strong>Times To Explore</strong></h2>

            <p class="subtitle">Start your new adventure here</p>


            </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div id="content11">
        <div class="container">
            <div class="row">
                <div class="col-md-12 headercontent">
                    <h4><b>Explore The World</b></h4>
                    <p class="p1">Discover a different side of 
                    these beloved cities</p>
                </div>
               	<?php $__currentLoopData = $packege; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allpack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
						<div class="col-lg-3 col-md-6 borderimg1">

						<a href="<?php echo e(route('experience-booking',$allpack->id)); ?>">
							<img src="<?php echo e(asset('/storage/packege/photo/'.$allpack->photo)); ?>"
							 class="img1" width="264px" height="175" />

							<div class="centered titleimg1 darkbg1">
							<?php echo e($allpack->destination->name); ?></div>
						</a>

						</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>	
    

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('fontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>