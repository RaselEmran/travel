<?php $__env->startSection('pageTitle'); ?> News <?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('page-header'); ?>
		<img src="<?php echo e(asset('fontend/images/bg6.jpg')); ?>" class="bg1"/>

				<div class="centered3 titleimg9">

					<h2>New Blog</h2>				

				</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
  	<div class="panel panel-default">
    <div class="panel-heading">
    	<img src="<?php echo e(asset('/storage/news/banner/'.$element->banner)); ?>" width="100%" height="250px" />
    </div>
    <div class="panel-body">
    	<a href="<?php echo e(route('news-details',['slug'=>$element->slug,'id'=>$element->id])); ?>"><?php echo e($element->title); ?></a>
    	<p class="label label-success"><?php echo e($element->category->name); ?></p>
    </div>
  </div>
 </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('fontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>