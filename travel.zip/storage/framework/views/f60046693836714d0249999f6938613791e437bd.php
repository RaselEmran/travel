<?php $__env->startSection('pageTitle'); ?> news-details <?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('page-header'); ?>
		<img src="<?php echo e(asset('/storage/news/banner/'.$details->banner)); ?>" class="bg1" height="400px" />

				<div class="centered3 titleimg9">

					<h2><?php echo e($details->title); ?></h2>				

				</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-12">
    <div class="panel panel-default">
    <div class="panel-heading">
      <img src="<?php echo e(asset('/storage/news/photo/'.$details->photo)); ?>" width="100%" height="250px" />
    </div>
    <div class="panel-body">
      <h4><?php echo e($details->short_content); ?></h4>
      <?php echo $details->news_content; ?>

      <p class="label label-success"><?php echo e($details->category->name); ?></p>
    </div>
  </div>
 </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('fontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>