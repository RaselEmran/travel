<?php $__env->startSection('pageTitle'); ?> Pages <?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<div class="page-header page-header-default">
    <div class="breadcrumb-line">
        <ul class="breadcrumb">
            <li><a href="index.html"><i class="icon-home2 position-left"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    
        <div class="col-md-12">
            <div class="panel panel-flat">
                <div class="panel-heading">
                    <h6 class="panel-title">Site Pages</h6>
                    <div class="heading-elements">
                        <ul class="icons-list">
                            <li><a data-action="collapse"></a></li>
                            <li><a data-action="reload"></a></li>
                            <li><a data-action="close"></a></li>
                        </ul>
                    </div>
                </div>

                <div class="panel-body">
                    <div class="tabbable">
                        <ul class="nav nav-tabs nav-tabs-highlight nav-justified">
                            <li class="active"><a href="#highlighted-justified-tab1" data-toggle="tab">About Us</a></li>
                            <li><a href="#highlighted-justified-tab2" data-toggle="tab">Contact Us</a></li>

                              <li><a href="#highlighted-justified-tab3" data-toggle="tab">Faq Page</a></li>


                        
                        </ul>

                   <form action="<?php echo e(route('admin.page.update')); ?>"  method="post" enctype="multipart/form-data" id="pages">
                            <div class="tab-content">
                            <div class="tab-pane active" id="highlighted-justified-tab1">

                                 <div class="row">
                                <div class="col-md-12">
                                      <div class="form-group">
                                        <label>About Heading:</label>
                                        <input type="text" name="abt_heading" id="abt_heading" class="form-control" placeholder="About Heading" value="<?php echo e($aboutinfo?$aboutinfo->abt_heading:''); ?>">
                                    </div>
                                </div>

                                   <div class="col-md-12">
                                    <div class="form-group">
                                        <label>About Content:</label>
                                        <textarea rows="5" cols="5" class="form-control summernote" name="abt_content" id="abt_content" placeholder="About Content" style="resize: none;"><?php echo e($aboutinfo?$aboutinfo->abt_content:''); ?></textarea>
                                    </div>
                                </div>

                                  <div class="col-md-6">
                                    <div class="form-group">
                                        <label>About Banner:</label>
                                        <input type="file" name="about_banner">
                                         <?php if($aboutinfo && isset($aboutinfo->about_banner)): ?>
                                            <input type="hidden" name="old_about_banner" value="<?php echo e($aboutinfo->about_banner); ?>">
                                         <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                <?php if($aboutinfo && isset($aboutinfo->about_banner)): ?>
                                    <img class="img-responsive img-thumbnail" src="<?php echo e(asset('/storage/pages/about/'.$aboutinfo->about_banner)); ?>" alt="" width="120px">
                                    <?php endif; ?>
                                </div>
                            </div>
                              <div class="row">
                         <h4>SEO Information</h4>
                            <div class="col-md-6">
                            <div class="form-group">
                                <label>Meta Title:</label>
                                <input type="text" name="abt_meta_title" id="abt_meta_title" class="form-control" placeholder="Meta Title" value="<?php echo e($aboutinfo?$aboutinfo->abt_meta_title:''); ?>">

                            </div>
                            </div>
                             <div class="col-md-6">
                                <div class="form-group">
                                <label>Meta Keywords:</label>
                                <input type="text" name="abt_meta_keywords" id="abt_meta_keywords" class="form-control" placeholder="Keywords" value="<?php echo e($aboutinfo?$aboutinfo->abt_meta_keywords:''); ?>">

                               </div>
                             </div> 
                       </div>
                          <div class="row">
                             <div class="col-md-12">
                                <div class="form-group">
                                <label>Meta Description:</label>
                                <textarea rows="5" cols="5" class="form-control " name="abt_meta_description" id="abt_meta_description" style="resize: none;" placeholder="Meta Description"><?php echo e($aboutinfo?$aboutinfo->abt_meta_description:''); ?></textarea>
                            </div>
                             </div>
                         </div>
                                
                        </div>

                            <div class="tab-pane" id="highlighted-justified-tab2">
                                   <div class="row">
                                <div class="col-md-12">
                                      <div class="form-group">
                                        <label>Contact Heading:</label>
                                        <input type="text" name="cnt_heading" id="cnt_heading" class="form-control" placeholder="Contact Heading" value="<?php echo e($contactinfo?$contactinfo->cnt_heading:''); ?>">
                                    </div>
                                </div>

                                   <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Contact Content:</label>
                                        <textarea rows="5" cols="5" class="form-control summernote" name="cnt_content" id="cnt_content" placeholder="Contact Content" style="resize: none;"><?php echo e($contactinfo?$contactinfo->cnt_content:''); ?></textarea>
                                    </div>
                                </div>

                                  <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Contact Banner:</label>
                                        <input type="file" name="contact_banner">
                                         <?php if($contactinfo && isset($contactinfo->contact_banner)): ?>
                                            <input type="hidden" name="old_contact_banner" value="<?php echo e($contactinfo->contact_banner); ?>">
                                         <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                <?php if($contactinfo && isset($contactinfo->contact_banner)): ?>
                                    <img class="img-responsive img-thumbnail" src="<?php echo e(asset('/storage/pages/contact/'.$contactinfo->contact_banner)); ?>" alt="" width="120px">
                                    <?php endif; ?>
                                </div>
                            </div>
                              <div class="row">
                            <h4>SEO Information</h4>
                            <div class="col-md-6">
                            <div class="form-group">
                                <label>Meta Title:</label>
                                <input type="text" name="cnt_meta_title" id="cnt_meta_title" class="form-control" placeholder="Meta Title" value="<?php echo e($contactinfo?$contactinfo->cnt_meta_title:''); ?>">

                            </div>
                            </div>
                             <div class="col-md-6">
                                <div class="form-group">
                                <label>Meta Keywords:</label>
                                <input type="text" name="cnt_meta_keywords" id="cnt_meta_keywords" class="form-control" placeholder="Keywords" value="<?php echo e($contactinfo?$contactinfo->cnt_meta_keywords:''); ?>">

                               </div>
                             </div> 
                         </div>
                          <div class="row">
                             <div class="col-md-12">
                                <div class="form-group">
                                <label>Meta Description:</label>
                                <textarea rows="5" cols="5" class="form-control " name="cnt_meta_description" id="cnt_meta_description" style="resize: none;" placeholder="Meta Description"><?php echo e($contactinfo?$contactinfo->cnt_meta_description:''); ?></textarea>
                            </div>
                             </div>
                         </div>

                            </div>

                        <div class="tab-pane active" id="highlighted-justified-tab3">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                        <label>Faq Banner:</label>
                                        <input type="file" name="faq_banner">
                                           <?php if($faqinfo && isset($faqinfo->faq_banner)): ?>
                                            <input type="hidden" name="old_faq_banner" value="<?php echo e($faqinfo->faq_banner); ?>">
                                         <?php endif; ?>
                                </div>  
                            </div>

                            <div class="col-md-6">
                                <?php if($faqinfo && isset($faqinfo->faq_banner)): ?>
                                    <img class="img-responsive img-thumbnail" src="<?php echo e(asset('/storage/pages/faq/'.$faqinfo->faq_banner)); ?>" alt="" width="120px">
                                    <?php endif; ?>
                                </div>


                                   <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Faq:</label>
                                        <textarea rows="5" cols="5" class="form-control summernote" name="faq" id="faq" placeholder="Faq" style="resize: none;"><?php echo e($faqinfo?$faqinfo->faq:''); ?></textarea>
                                    </div>
                                </div>
                        </div>
                        </div>
                         <div class="text-right">
                <button type="submit" class="btn btn-primary"  id="submit">Upadte Page<i class="icon-arrow-right14 position-right"></i></button>
                <button type="button" class="btn btn-link" id="submiting" style="display: none;">Processing <img src="<?php echo e(asset('ajaxloader.gif')); ?>" width="80px"></button>
            </div>
                        </div>
                   </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/editors/summernote/summernote.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/forms/styling/uniform.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/demo_pages/editor_summernote.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/demo_pages/form_checkboxes_radios.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/notifications/sweet_alert.min.js')); ?>"></script>

<script src="<?php echo e(asset('backend/assets/js/pages.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>