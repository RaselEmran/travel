<?php $__env->startSection('pageTitle'); ?> booking Details <?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('fontend/css/toastr.min.css')); ?>" rel="stylesheet">

<?php $__env->stopPush(); ?>

<?php $__env->startSection('procontent'); ?>

	<div class="col-md-8 booking-order-details">
    <img src="<?php echo e(asset('/storage/packege/banner/'.$packege->packege->banner)); ?>" alt="" class="img-responsive">
     <h4 class="label label-primary">Packege Info</h4>
     <table class="table">
         <tr>
             <th>Packege Name</th>
             <th>Destination Name</th>
             <th>Duration</th>
         </tr>
         <tr>
             <td><?php echo e($packege->packege->name); ?></td>
             <td><?php echo e($packege->packege->destination->name); ?></td>
             <td><?php echo e($packege->packege->duration); ?>Hours</td>
         </tr>
     </table>
     <div>
         <h4 class="label label-info">Booking Info</h4>
         <table class="table">
             <tr>
                 <th>Packege Type</th>
                 <th>Depart date</th>
                 <th>Pack Quantity</th>
                 <th>Price</th>
                 <th>Total</th>
             </tr>
             <tr>
                 <td><?php echo e($packege->type); ?></td>
                 <td><?php echo e($packege->depart_date); ?></td>
                 <td><?php echo e($packege->pack_quantity); ?></td>
                 <td><?php echo e($packege->price); ?></td>
                 <td><?php echo e($packege->total); ?></td>
             </tr>
         </table>
     </div>

        <div>
         <h4 class="label label-default">Your Itinary</h4>
         <table class="table">
             <tr>
                 <th>Time</th>
                 <th>Name</th>
             </tr>
             <tr>
               <?php $__currentLoopData = $packege->useritinary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                     <td><?php echo e($element->time); ?></td>
                     <td><?php echo e($element->name); ?></td>
                 </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tr>
         </table>
         <h3>Your Tour Status <?php if($packege->status==0): ?>
             <span class="label label-danger">Pendding</span>
             <?php else: ?>
             <span class="label label-success">Mail Sent</span>
         <?php endif; ?></h3>
     </div>
    </div>
		

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('fontend/js/toastr.min.js')); ?>"></script>
<script>
$('.select').select2();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('fontend.profile.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>