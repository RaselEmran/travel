	<div class="row">

			<div id="content10">

				<div class="darkbg4">

				<div class="row">

					<div class="col-md-3">

						<p class="headertitle1">YuPa Discovery Sdn Bhd</p>

						<p class="subtext1">No.18, Lorong Aman, Georgetown, 10350 Pulau Pinang 04 - 227 0766 lets.yupa@gmail.com</p>

					</div>			

					<div class="col-md-3">

						<p class="headertitle1">Resources</p>

						<p class="subtext1"><a href="<?php echo e(route('about-us')); ?>">About us</a></p>

						<p class="subtext1">Terms and conditions</p>

						<p class="subtext1">Privacy Policy</p>

						<p class="subtext1"><a class="nav" href="<?php echo e(route('home.news')); ?>">Blog</a></p>

						<p class="subtext1">Career</p>

						<p class="subtext1">FAQ</p>

					</div>

					<div class="col-md-3">

						<p class="headertitle1">Partnerships</p>

						<p class="subtext1">Partner Login</p>

						<p class="subtext1">Affiliate Partnership</p>

						<p class="subtext1">Influencer Program</p>

						<p class="subtext1">Agent Marketplace</p>

					</div>

					<div class="col-md-3">		

						<p class="headertitle1">Social Media</p>

						<p class="subtext1">

						<img src="<?php echo e(asset('fontend/images/linked_in.png')); ?>" class="icon-media"/>

						<img src="<?php echo e(asset('fontend/images/facebook.png')); ?>" class="icon-media"/>

						<img src="<?php echo e(asset('fontend/images/instagram.png')); ?>" class="icon-media"/>

						<img src="<?php echo e(asset('fontend/images/youtube.png')); ?>" class="icon-media"/>

						</p>

						<br>

						<br>

						<br>

						<br>

						<p class="headertitle1">Payment Method</p>

						<p class="subtext1">

						<img src="<?php echo e(asset('fontend/images/mastercard.jpg')); ?>" class="icon-payment"/>

						<img src="<?php echo e(asset('fontend/images/visa.jpg')); ?>" class="icon-payment"/>

						<img src="<?php echo e(asset('fontend/images/paypal.jpg')); ?>" class="icon-payment"/>

						<img src="<?php echo e(asset('fontend/images/american-express.jpg')); ?>" class="icon-payment"/>

						</p>

					</div>

					

				</div>

			

			</div>

			</div>

		</div>
  <div class="row">

		<center><p class="copyright">&copy; 2019 YuPa Discovery Sdn. Bhd. All right reserved.</p></center>

	</div>