<?php $__env->startSection('pageTitle'); ?> dashboard <?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
 <link href="<?php echo e(asset('backend/global_assets/css/icons/icomoon/styles.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page-header'); ?>
<img src="<?php echo e(asset('/storage/hotel/banner/'.$hotel->banner)); ?>" class="bg1"/ width="1351px" height="368px">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container row">
	<div class="col-md-12">
		<button class="btn btn-gallery view-hotel-img"><img src="<?php echo e(asset('fontend/images/image-gallery.png')); ?>" height="16px" width="16px" /><span style="padding-left: 5px;">View Photos</span></button>
	</div>
</div>
</div>
</div>
<br>
<div class="row">
<div id="content12">
<div class="container">
	<div class="row">
		<div class="col-md-7">
			<div class="row">
				<div class="col-md-12">
					<span class="state">State > </span><span class="area">Balik Pulau</span>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<h3><?php echo e($hotel->name); ?></h3>
				</div>
			</div>
			
			<br>
			<?php if($hotel->entire_place): ?>
			<div class="row">
				<div class="col-md-12">
					<span><b>Entire Place :</b></span>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<span class="entires"><?php echo e($hotel->entire_place); ?></span>
				</div>
			</div>
			<br>
			<?php endif; ?>
			<br>
			<?php if($hotel->room_details): ?>
			<div class="row">
				<div class="col-md-12">
					<h4 class="hotel-sub-titles">Room Details</h4>
				</div>
				<div class="col-md-12">
					<div class="room-detail-desc">
						<?php echo $hotel->room_details; ?>

					</div>
				</div>
			</div>
			<br>
			<?php endif; ?>
			<?php if($hotel->amenities->count() > 0): ?>
			<div class="row">
				<div class="col-md-12">
					<h4 class="hotel-sub-titles">Amenity</h4>
				</div>
				<?php $__empty_1 = true; $__currentLoopData = $hotel->amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div class="col-md-6">
					<div class="amenity">
						<i class="<?php echo e($amenity->amenity->icon); ?>"></i>&nbsp;<?php echo e($amenity->amenity->name); ?>

					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<?php endif; ?>
			</div>
			<br>
			<?php endif; ?>
			<?php if($hotel->rules): ?>
			<div class="row">
				<div class="col-md-12">
					<h4 class="hotel-sub-titles">Rules</h4>
				</div>
				<div class="col-md-12">
					<?php echo e($hotel->rules); ?>

				</div>
			</div>
			<br>
			<?php endif; ?>
			<?php if($hotel->allow): ?>
			<div class="row">
				<div class="col-md-12">
					<h4 class="hotel-sub-titles">Allow / Not allow</h4>
				</div>
				<div class="col-md-12">
					<?php echo $hotel->allow; ?>

				</div>
			</div>
			<br>
			<?php endif; ?>
			<?php if($hotel->map): ?>
			<div class="row">
				<div class="col-md-12">
					<h4 class="hotel-sub-titles">Map</h4>
				</div>
				<div class="col-md-12">
					<?php echo $hotel->map; ?>

				</div>
			</div>
			<br>
			<?php endif; ?>
			<?php if($hotel->policy): ?>
			<div class="row">
				<div class="col-md-12">
					<h4 class="hotel-sub-titles">Cancellation Policy</h4>
				</div>
				<div class="col-md-12">
					<?php echo $hotel->policy; ?>

				</div>
			</div>
			<?php endif; ?>
		</div>
		<div class="col-md-1"></div>
		<div class="col-md-4 booking-price-container">
			<div>
				<div class="col-md-12" style="padding-bottom: 5px;">
					<img src="<?php echo e(asset('fontend/images/question-mark.png')); ?>" /> Price Guarantee
				</div>
				<div class="col-md-12">
					<span class="price-label">RM <?php echo e($hotel->price); ?></span><span class="per-night"> per night</span>
				</div>
				<div class="col-md-12">
					<hr>
				</div>
				<div class="col-md-12">
					<form action="<?php echo e(route('hotel.booking', $hotel->id)); ?>" method="POST" id="hotel_for">
						<?php echo e(csrf_field()); ?>

						<div class="row">
							<div class="col-md-12">
								<label>Check-in</label>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12" style="padding-bottom: 10px;">
								<input type="hidden" value="<?php echo e($hotel->id); ?>" name="hotel_id">
								<input type="hidden" value="<?php echo e($hotel->price); ?>" name="price">
								<input type="date" id="check_in" class="form-control form-control100" name="check_in" required />
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label>Check-out</label>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12" style="padding-bottom: 10px;">
								<input type="date" id="check_out" class="form-control form-control100" name="check_out" required />
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label>Select number of guest</label>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12" style="padding-bottom: 10px;">
								<select id="select-guest" class="form-control form-control-2" name="guest" required >
									<option value="">Select Guest</option>
									<option value='1'>1</option><option value='2'>2</option><option value='3'>3</option><option value='4'>4</option><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8'>8</option><option value='9'>9</option><option value='10'>10</option><option value='11'>11</option><option value='12'>12</option><option value='13'>13</option><option value='14'>14</option><option value='15'>15</option><option value='16'>16</option><option value='17'>17</option><option value='18'>18</option><option value='19'>19</option><option value='20'>20</option>											</select>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12" style="padding-bottom: 10px;">
									<input type="submit" class="form-control form-control-2 btn btn-info" value="Book" />
								</div>
							</div>
							<div>
								You won't be charged yet
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
<hr>
<div class="row">
<div id="content11">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<span><h4><b>More place you may like</b></h4></span><span class="flt-right" ><a href="" class="view-all-hotel">View all ></a></span>
			</div>
			<?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-lg-3 col-md-6 borderimg1">
					<center>
					<div class="darkbg3">
						<img src="<?php echo e(asset('/storage/hotel/photo/'.$hotel->photo)); ?>" class="img3"/>
						<div class="row">
							<div class="col-md-12 titleimg4"><a href="<?php echo e(route('hotel.show', $hotel->id)); ?>"><?php echo e($hotel->name); ?></a></div>
							<div class="col-md-7 reviewcontainer">
								<img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><span class="review"> (188)</span>
							</div>
							<div class="col-md-5 price1">MYR <?php echo e($hotel->price); ?></div>
						</div>
					</div>
					</center>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<!--===============================================================================================-->

<script type="text/javascript" src="<?php echo e(asset('fontend/js/hotel-booking.js')); ?>"></script>
<script src="<?php echo e(asset('fontend/js/toastr.min.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('fontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>