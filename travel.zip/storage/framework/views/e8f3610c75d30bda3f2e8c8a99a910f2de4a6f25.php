<tr>
    <td colspan="1">
         <input type="date" name="packege_variation[<?php echo e($row); ?>][variation][<?php echo e($variation_id); ?>][itinary_date]" id="itinary_date" class="form-control" placeholder="Itinary Date">  
     </td>
     <td colspan="2">
          <input type="text" name="packege_variation[<?php echo e($row); ?>][variation][<?php echo e($variation_id); ?>][itinary_name]" id="itinary_name" class="form-control" placeholder="Itinary Name">  
     </td>
     <td>
         <button type="button" class="btn btn-danger btn-xs remove_variation_value_row" data-id="<?php echo e($row); ?>">-</button>
     </td>
 </tr>