<?php $__env->startSection('pageTitle'); ?> Hotel Booking List <?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('fontend/css/toastr.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('procontent'); ?>
<div class="col-md-8 booking-order-details">
    <div class="container-fluid">
        <div class="row">
            <?php if(Session::has('message')): ?>
            <p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
            <?php endif; ?>
            <div class="col-md-12">
                <span class="vertical-box"></span><span style="font-size: 24px!important; font-weight: bold; ">Hotel Bookings</span>
                <p class="grey-txt">This information is used to autofill your details to make it quicker for you to book. Your details will be stored securely and won't be shared publicly.</p>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel_booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 borderimg1">
                <center>
                <div class="darkbg3" style="width: 225px;">
                    <img src="<?php echo e(asset('/storage/hotel/photo/'.$hotel_booking->hotel->photo)); ?>" class="img3" style="width: 225px;" />
                    <div class="row">
                        <div class="col-md-12 titleimg4"><a href="<?php echo e(route('hotel.booking_details', $hotel_booking->id)); ?>"><?php echo e($hotel_booking->hotel->name); ?></a></div>
                        <div class="col-md-7 reviewcontainer">
                            <img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><span class="review"> (188)</span>
                        </div>
                        <div class="col-md-5 price1">MYR <?php echo e($hotel_booking->price); ?></div>
                    </div>
                </div>
                </center>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
            <?php echo $hotels->links(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('fontend/js/toastr.min.js')); ?>"></script>
<script>
$('.select').select2();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('fontend.profile.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>