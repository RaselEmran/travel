<?php $__env->startSection('pageTitle'); ?> Hotel Booking Details <?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('fontend/css/toastr.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('procontent'); ?>
<div class="col-md-8 booking-order-details">
    <div>
        <h4>Booking Status</h4>
        <?php if($hotel_booking->status == 0): ?>
        <button class="btn btn-sm btn-warning">Pending</button>
        <?php endif; ?>
    </div>
    <div>
        <h4>Booking Info</h4>
        <table class="table">
            <tr>
                <th>Check In Date</th>
                <th>Check Out Date</th>
                <th>Guest</th>
                <th>Price</th>
            </tr>
            <tr>
                <td><?php echo e($hotel_booking->check_in); ?></td>
                <td><?php echo e($hotel_booking->check_out); ?></td>
                <td><?php echo e($hotel_booking->guest); ?></td>
                <td><?php echo e($hotel_booking->price); ?></td>
            </tr>
        </table>
    </div>
    <h4>Hotel Info</h4>
    <table class="table table-bordered">
        <tbody>
            <tr>
                <td>Hotel Name</td>
                <td><?php echo e($hotel_booking->hotel->name); ?></td>
            </tr>
            <?php if($hotel_booking->hotel->entire_place): ?>
            <tr>
                <td>Entire Place :</td>
                <td><?php echo e($hotel_booking->hotel->entire_place); ?></td>
            </tr>
            <?php endif; ?>
            <?php if($hotel_booking->hotel->room_details): ?>
            <tr>
                <td>Room Details</td>
                <td><?php echo $hotel_booking->hotel->room_details; ?></td>
            </tr>
            <?php endif; ?>
            <tr>
                <td>Amenity</td>
                <td>
                    <?php $__empty_1 = true; $__currentLoopData = $hotel_booking->hotel->amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo e($amenity->amenity->name . ', '); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    No Amenity Found
                    <?php endif; ?>
                </td>
            </tr>
            <?php if($hotel_booking->hotel->rules): ?>
            <tr>
                <td>Rules</td>
                <td><?php echo $hotel_booking->hotel->rules; ?></td>
            </tr>
            <?php endif; ?>
            <?php if($hotel_booking->hotel->allow): ?>
            <tr>
                <td>Allow / Not allow</td>
                <td><?php echo $hotel_booking->hotel->allow; ?></td>
            </tr>
            <?php endif; ?>
            <?php if($hotel_booking->hotel->map): ?>
            <tr>
                <td>Map</td>
                <td><?php echo $hotel_booking->hotel->map; ?></td>
            </tr>
            <?php endif; ?>
            <?php if($hotel_booking->hotel->policy): ?>
            <tr>
                <td>Cancellation Policy</td>
                <td><?php echo $hotel_booking->hotel->policy; ?></td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('fontend/js/toastr.min.js')); ?>"></script>
<script>
$('.select').select2();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('fontend.profile.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>