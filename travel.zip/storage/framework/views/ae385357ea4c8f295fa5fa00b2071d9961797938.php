<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
</head>
<body>
	<div>
		<p>Dear Sir <?php echo e($user->name); ?></p>
		<p>Thank you for your Order</p>
	</div>
	<div>
		<?php echo $messege; ?>

	</div>
</body>
</html>