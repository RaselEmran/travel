<!--<nav class="container-fluid">-->

<nav class="bg-white-nav">

  <div class="navbar minus-bottom" style="padding: .5rem 1rem;">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
            <!-- <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span> -->
              <img id="sidemenu" src="<?php echo e(asset('fontend/images/menu.png')); ?>">                       
            </button>

            <a class="navbar-brand" href="<?php echo e(URL::to('/')); ?>"><img src="<?php echo e(asset('fontend/images/yupa-logo-blue.png')); ?>" style="width: 165px; height: 45px; margin-top: -10px;"></a>
        </div>

        <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                <li><a href="<?php echo e(route('home.index')); ?>" class="text-nav-black">Home</a></li>
			     <?php if(Auth::guest()): ?>
                    <li><a href="<?php echo e(route('login')); ?>" class="text-nav-black">Login</a></li>
                    <li><a href="<?php echo e(route('sign-up-option')); ?>" class="item-white text-nav-black">Sign Up</a></li>
                    <?php else: ?>
                    <li><a href="<?php echo e(route('dashboard')); ?>" class="text-nav-black">Dashboard</a></li>
			       <?php endif; ?>
                    <li><a href="" class="text-nav-black">MYR</a></li>
                    <li><a href="" class="item-white text-nav-black">Help</a></li>
                </ul>
        </div>
    </div>

</nav>