<?php $__env->startSection('pageTitle'); ?> dashboard <?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('fontend/css/toastr.min.css')); ?>" rel="stylesheet">

<?php $__env->stopPush(); ?>

<?php $__env->startSection('procontent'); ?>

	<div class="col-md-8 booking-order-details">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <span class="vertical-box"></span><span style="font-size: 24px!important; font-weight: bold; ">Bookings</span>
                        <p class="grey-txt">This information is used to autofill your details to make it quicker for you to book. Your details will be stored securely and won't be shared publicly.</p>
                    </div>
                </div>
                <div class="row">
                <?php $__currentLoopData = $userpackege; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allpack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="col-lg-4 col-md-6 borderimg1">
                          <a href="<?php echo e(route('experience-booking',$allpack->packege->id)); ?>">
					<img src="<?php echo e(asset('/storage/packege/photo/'.$allpack->packege->photo)); ?>"
					 class="img1" width="235px" height="175" />

					<div class="centered titleimg1 darkbg1">
					<?php echo e($allpack->packege->destination->name); ?></div>
				</a>
                        
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </div>
            </div>
    </div>
		

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('fontend/js/toastr.min.js')); ?>"></script>
<script>
$('.select').select2();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('fontend.profile.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>