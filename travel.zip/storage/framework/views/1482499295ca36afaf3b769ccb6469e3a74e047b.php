<?php $__env->startSection('pageTitle'); ?> dashboard <?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('fontend/css/toastr.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page-header'); ?>
<img src="<?php echo e(asset('fontend/images/bg8.jpg')); ?>" class="bg1"/>
	<div class="container row">
		<div class="col-md-12">
			<button class="btn btn-gallery view-hotel-img"><img src="<?php echo e(asset('fontend/images/image-gallery.png')); ?>" height="16px" width="16px" /><span style="padding-left: 5px;">View Photos</span></button>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div id="content12">
		<div class="container">
			<div class="row">
				<div class="col-md-8">
					<div class="row">
					</div>
					<div class="row">
						<div class="col-md-12">
							<h3><?php echo e($packege->name); ?></h3>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<span class="hotel-review">
								<img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/>
								<img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/>
								<img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/>
								<img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/>
								<img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/>
								<span class="review">&nbsp;&nbsp;1 review</span>
							</span>
						</div>
					</div>
					<br>
					<div class="row">
						<div class="col-md-12">
							<span>Duration : </span><span> <?php echo e($packege->duration); ?> hour(s)</span>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<span>Location : </span><span> <?php echo e($packege->destination->name); ?></span>
						</div>
					</div>
					<br>
					<div class="row">
						<div class="col-md-8">
							<h4 class="hotel-sub-titles">Reviews</h4>
						</div>
						<div class="col-md-4">
							<a class="view-more-review">More reviews</a>
						</div>
					</div>
					<div class="row">
						<div class="review-hotel-container">
							<div class="col-md-2">
								<span>
									<img src="<?php echo e(asset('fontend/images/profile-pic.png')); ?>" class="profile-pic-comment" />
								</span>
							</div>
							<div class="col-md-10">
								<div class="comment-name">Tsunghsien</div>
								<div class="comment-review-star">
									<img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><span class="review">&nbsp;&nbsp;2019/04/15</span>
								</div>
								<div class="comment-review-desc">
									Miss Lu, a young and bloody student, has many stories about the Big Island. Listening and listening to the spirit are coming! Although the volcano is not erupting now. But the beautiful story is also a good experience.
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4 booking-price-container">
					<div>
						<div class="col-md-12" style="padding-bottom: 5px;">
							<img src="<?php echo e(asset('fontend/images/question-mark.png')); ?>" />
							Price Guarantee
						</div>
						<div class="col-md-6" style="padding-bottom: 20px;">
							<label>
								Start form
							</label>
						</div>
						<div class="col-md-6" style="padding-bottom: 20px;">
							<span class="price-label" style="float: right;"><?php echo e($packege->one_way_price); ?></span>
						</div>
						<div class="col-md-12" style="padding-bottom: 20px;">
							<a href="#package-options-content" class="btn btn-info btn-book-redirect">Book</a>
						</div>
						<div class="col-md-12" style="padding-bottom: 20px;">
							<p>To be confirmed within 3 working day(s)</p>
						</div>
					</div>
				</div>
				
				<div class="col-md-12">
					<div id="package-options-content"></div>
					<br>
					<div class="row">
						<div class="col-md-12 package-options bg-experience">
							<div class="container-fluid">
								<div class="col-md-12">
									<h4 class="hotel-sub-titles">
									Package options
									</h4>
								</div>
								<form action="<?php echo e(route('itinaray-up')); ?>" method="POST" id="itinaryForm">
								<?php echo csrf_field(); ?>
									<input type="hidden" name="packege_id" value="<?php echo e($packege->id); ?>">
												<div class="col-md-7">
													<div class="one-way">
														<div class ="row">
															<b><span class="col-md-8"><?php echo e($packege->name); ?> (One Way)</span><span class="price-package">RM<?php echo e($packege->one_way_price); ?></span>
															<span id="ck-button"><label><input type="checkbox" id="one-way-pack" class="hidden" name="one_way" value="1" onclick="showDiv('one-way-pack')" /><span>Select</span></label></span></b>
															<input type="hidden" name="one_price" value="<?php echo e($packege->one_way_price); ?>">
														</div>
														<div id="package-details-container-one" class="row">
															<div class="col-md-6">
																<div><label>Select Depart Date</label></div>
																<div style="padding-bottom: 10px;"><input type="date" id="depart-date" class="form-control" name="depart_date" onchange="getPackageDetail('depart-date')" required /></div>
															</div>
															<div class="col-md-6">
															</div>
															<div class="col-md-12">
																<label>Select Pack Quantity</label>
															</div>
															<div class="col-md-6">
																<div style="padding-bottom: 10px;">
																	<select id="pack-quantity" class="form-control" name="pack_quantity" onchange="getPackageDetail('pack-quantity')" required>
																		<option value="">Select Pack Quantity</option>
																		<option value='1'>1</option>
																		<option value='2'>2</option>
																		<option value='3'>3</option>
																		<option value='4'>4</option>
																		<option value='5'>5</option>
																		<option value='6'>6</option>
																		<option value='7'>7</option>
																		<option value='8'>8</option>
																		<option value='9'>9</option>
																		<option value='10'>10</option>
																		<option value='11'>11</option>
																		<option value='12'>12</option>
																		<option value='13'>13</option>
																		<option value='14'>14</option>
																		<option value='15'>15</option>
																		<option value='16'>16</option>
																		<option value='17'>17</option>
																		<option value='18'>18</option>
																		<option value='19'>19</option>
																		<option value='20'>20</option>
																	</select>
																</div>
															</div>
															<div class="col-md-6">
															</div>
															<div class="col-md-12">
																<p>Your Itinerary :</p>
															</div>
															<?php $__currentLoopData = $packege->oneway; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															
															<div class="col-md-3">
																<input type="time" id="time1-0" class="form-control form-control100 itinerary-form1" name="time1[]" value="<?php echo e($one->time1); ?>" readonly />
															</div>
															<div class="col-md-9">
																<input type="text" id="activity1-0" class="form-control form-control100 itinerary-form1" name="itinary_name1[]" value="<?php echo e($one->itinary_name1); ?>" readonly />
															</div>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														
															<div id="itinerary-container1">
															</div>
															<div class="col-md-3">
																<button type="button" id="edit-itinerary-btn1" class="btn btn-info form-control" name="edit-btn1">Edit</button>
															</div>
															<div class="col-md-3">
																<button type="button" id="add-itinerary-btn1" class="btn btn-info form-control" name="add-btn1">Add</button>
															</div>
															<input type="hidden" id="price-package-select" name="price-package" value="<?php echo e($packege->one_way_price); ?>" />
														</div>
													</div>
													<div class="two-way">
														<div class ="row package-details-two-way">
															<b><span class="col-md-8"><?php echo e($packege->name); ?> (Two Way)</span><span class="price-package">RM<?php echo e($packege->two_way_price); ?></span>
															<span id="ck-button1"><label><input type="checkbox" id="two-way-pack" class="hidden" name="two-way" value="1" onclick="showDiv('two-way-pack')" /><span>Select</span></label></span></b>
															<input type="hidden" name="two_price" value="<?php echo e($packege->two_way_price); ?>">
														</div>
														<div id="package-details-container-two" class="row">
															<div class="col-md-6">
																<div><label>Select Depart Date</label></div>
																<div style="padding-bottom: 10px;"><input type="date" id="depart-date2" class="form-control"  name="depart_date2"  onchange="getPackageDetail2('depart-date2')" required />
															</div>
														</div>
														<div class="col-md-6">
														</div>
														<div class="col-md-12">
															<label>Select Pack Quantity</label>
														</div>
														<div class="col-md-6">
															<div style="padding-bottom: 10px;">
																<select id="pack-quantity2" class="form-control" name="pack_quantity2"  onchange="getPackageDetail2('pack-quantity2')" required >
																	<option value="">Select Pack Quantity</option>
																	<option value='1'>1</option><option value='2'>2</option><option value='3'>3</option><option value='4'>4</option><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8'>8</option><option value='9'>9</option><option value='10'>10</option><option value='11'>11</option><option value='12'>12</option><option value='13'>13</option><option value='14'>14</option><option value='15'>15</option><option value='16'>16</option><option value='17'>17</option><option value='18'>18</option><option value='19'>19</option><option value='20'>20</option>															</select>
																</div>
															</div>
															<div class="col-md-6">
															</div>
															<div class="col-md-12">
																<p>Your Itinerary :</p>
															</div>
															<?php $__currentLoopData = $packege->twoway; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $two): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																
															
															<div class="col-md-3">
																<input type="time" id="time2-0" class="form-control form-control100 itinerary-form2" name="time2[]" value="<?php echo e($two->time2); ?>" readonly />
															</div>
															<div class="col-md-9">
																<input type="text" id="activity2-0" class="form-control form-control100 itinerary-form2" name="itinary_name2[]" value="<?php echo e($two->itinary_name2); ?>" readonly />
															</div>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													
															<div id="itinerary-container2">
																
															</div>
															<div class="col-md-3">
																<button type="button" id="edit-itinerary-btn2" class="btn btn-info form-control" name="edit-btn2">Edit</button>
															</div>
															<div class="col-md-3">
																<button type="button" id="add-itinerary-btn2" class="btn btn-info form-control" name="add-btn2">Add</button>
															</div>
															<input type="hidden" id="price-package-select2" name="price-package" value="500" />
														</div>
													</div>
												</div>
												<div class="col-md-5 booking-price-container">
													<div>
														<div class="col-md-12" style="padding-bottom: 5px;">
															<img src="<?php echo e(asset('fontend/images/question-mark.png')); ?>" /><label>&nbsp;Order Details</label>
														</div>
														<div class="col-md-12" style="padding-bottom: 20px;">
															<label><span><?php echo e($packege->name); ?> </span><span id="option-package-selected"></span></label>
														</div>
														<div class="col-md-12" style="padding-bottom: 20px;">
															<span id="depart-date-txt" class="depart-date-details flt-left" style="float: left;"></span>
														</div>
														<div class="col-md-12">
															<div class="order-details">
																<div id="package-op" class="col-md-5"></div>
																<div id="pack-quantity-txt" class="col-md-3 align-right-col"></div>
																<div id="price-txt" class="col-md-4 align-right-col"></div>
															</div>
														</div>
														<div class="col-md-12">
															<div class="order-total-prices">
																<div class="col-md-6">Total</div>
																<div id="total-price-txt" class="col-md-6 align-right-col"></div>
															</div>
														</div>
														<?php if(Auth::user()): ?>
														<div class="col-md-12" style="padding-bottom: 20px;">
															<input type="submit" class="btn btn-info btn-book" name="book-btn" value="Book now" />
														</div>
														<?php else: ?>
														<div class="col-md-12" style="padding-bottom: 20px;">
															<a href="<?php echo e(route('login')); ?>" class="btn btn-info btn-book">Book Now</a>
														</div>
														<?php endif; ?>
														<div class="col-md-12" style="padding-bottom: 10px;">
															<p>To be confirmed within 3 working day(s)</p>
														</div>
														<div class="col-md-12">
															<a href="" class="wishlist-btn"> Add to Wishlists</a>
														</div>
													</div>
												</div>
											</form>
							</div>
						</div>
					</div>
				</div>
				<br>
				<br>
				<div class="col-md-7" style="padding-top: 50px;">
					<div class="row">
						<div class="col-md-12">
							<h4 class="hotel-sub-titles">Description</h4>
						</div>
						<div class="col-md-12">
						<?php echo $packege->description; ?>

						</div>
					
					</div>
					<br>
					<div class="row">
						<div class="col-md-12">
							<h4 class="hotel-sub-titles">Inclusive of</h4>
						</div>
						<div class="col-md-12">
						<?php echo $packege->inclusive_of; ?>

						</div>
					
					</div>
					<br>
					<div class="row">
						<div class="col-md-12">
							<h4 class="hotel-sub-titles">Not inclusive of</h4>
						</div>
						<div class="col-md-12">
						<?php echo $packege->not_inclusive_of; ?>

						</div>
						
					</div>
					<br>
					<div class="row">
						<div class="col-md-12">
							<h4 class="hotel-sub-titles">Booking information</h4>
						</div>
						<div class="col-md-12">
						<?php echo $packege->booking_info; ?>

						</div>
						<div class="col-md-12">
							<a class="show-all">Show all ></a>
						</div>
					</div>
					<br>
					<div class="row">
						<div class="col-md-12">
							<h4 class="hotel-sub-titles">Map</h4>
						</div>
						<div class="col-md-12">
							<?php echo e($packege->destination->name); ?>

						</div>
						<div class="col-md-12">
							<?php echo $packege->location; ?>

						</div>
					</div>
					<br>
					<div class="row">
						<div class="col-md-12">
							<h4 class="hotel-sub-titles">Cancellation Policy</h4>
						</div>
						<div class="col-md-12">
						<?php echo $packege->policy; ?>

						</div>
						
					</div>
				</div>
				<div class="col-md-1"></div>
			</div>
		</div>
	</div>
	</div>
	<hr>
	<?php if(count($latest)>0): ?>

<div class="row">
<div id="content11">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<span><h4><b>More place you may like</b></h4></span
			</div>
			<?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-lg-3 col-md-6 borderimg1">
					<center>
					<div class="darkbg3">
						<img src="<?php echo e(asset('/storage/hotel/photo/'.$hotel->photo)); ?>" class="img3"/>
						<div class="row">
							<div class="col-md-12 titleimg4"><a href="<?php echo e(route('hotel.show', $hotel->id)); ?>"><?php echo e($hotel->name); ?></a></div>
							<div class="col-md-7 reviewcontainer">
								<img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><img src="<?php echo e(asset('fontend/images/star.png')); ?>" class="staricon"/><span class="review"> (188)</span>
							</div>
							<div class="col-md-5 price1">MYR <?php echo e($hotel->price); ?></div>
						</div>
					</div>
					</center>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<!--===============================================================================================-->

<script type="text/javascript" src="<?php echo e(asset('fontend/js/experience-booking.js')); ?>"></script>
<script src="<?php echo e(asset('fontend/js/toastr.min.js')); ?>"></script>
		<script>
		function onSuccess(googleUser) {
			console.log('Logged in as: ' + googleUser.getBasicProfile().getName());
		}
		function onFailure(error) {
			console.log(error);
		}
		function renderButton() {
			gapi.signin2.render('my-signin2', {
			'scope': 'profile email',
			'width': 240,
			'height': 50,
			'longtitle': true,
			'theme': 'dark',
			'onsuccess': onSuccess,
			'onfailure': onFailure
			});
		}
		</script>
		
		<script>
		function showPass() {
			var x = document.getElementById("password");
			if (x.type === "password") {
				x.type = "text";
			} else {
				x.type = "password";
				}
		}
		</script>

		<script>
		$(document).ready(function(){
		$("#ck-button").click(function(){
			$("p").toggle();
		});
		$("#show").click(function(){
			$("p").show();
		});
		});
		</script>

<?php $__env->stopPush(); ?>	
<?php echo $__env->make('fontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>