	<div class="panel panel-flat">
			<div class="panel-heading">
				<h5 class="panel-title">View Details</h5>
	
			</div>

			<div class="panel-body">
				<table class="table table-bordered">
					<tbody>
						<tr>
							<td>Destination Name</td>
							<td><?php echo e($destination->name); ?></td>
						</tr>

						<tr>
							<td>Heading</td>
							<td><?php echo e($destination->heading); ?></td>
						</tr>

						<tr>
							<td>Short Description</td>
							<td><?php echo e($destination->short_description); ?></td>
						</tr>

						 <tr>
							<td>Package Heading</td>
							<td><?php echo e($destination->pkg_heading); ?></td>
						  </tr>

						   <tr>
							<td>Package Subheading</td>
							<td><?php echo e($destination->pkg_subheading); ?></td>
						  </tr>

						   <tr>
							<td>Detail Heading</td>
							<td><?php echo e($destination->pkg_detailsheading); ?></td>
						  </tr>

						   <tr>
							<td>Detail Subheading</td>
							<td><?php echo e($destination->pkg_details_subheading); ?></td>
						  </tr>
						  <tr>
							<td>Introduction</td>
							<td><?php echo $destination->introduction; ?></td>
						  </tr>
						  <tr>
							<td>Experience</td>
							<td><?php echo $destination->experience; ?></td>
						  </tr>


						  <tr>
							<td>Hotel</td>
							<td><?php echo $destination->hotel; ?></td>
						  </tr>

						  <tr>
							<td>Transpotation</td>
							<td><?php echo $destination->transportation; ?></td>
						  </tr>

						    <tr>
							<td>Culture</td>
							<td><?php echo $destination->culture; ?></td>
						  </tr>


						    <tr>
							<td>Featured Photo</td>
							<td> <img src="<?php echo e(asset('/storage/destination/photo/'.$destination->photo)); ?>" alt="" width="150px"></td>
						  </tr>


						    <tr>
							<td>Banner</td>
							<td> <img src="<?php echo e(asset('/storage/destination/banner/'.$destination->banner)); ?>" alt="" width="150px"></td>
						  </tr>

					</tbody>
				</table>
				<div class="text-right">
			
					 <button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>