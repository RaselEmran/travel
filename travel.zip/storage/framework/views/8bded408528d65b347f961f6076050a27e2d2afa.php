<!-- Footer -->
<div class="footer text-muted" style="text-align: center;background: #eee">
      <!-- Don't remove below text. Its against copy right laws. -->
    <strong>Super Erp System- </strong> || Developed by <a class="cplink" href=""><a>
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="#"><?php if(isset($appSettings['bussiness_settings']['bussiness_name'])): ?><?php echo e($appSettings['bussiness_settings']['bussiness_name']); ?><?php else: ?> SATT ERP <?php endif; ?></a>.</strong> All rights
    reserved.

      <div class="btn-group pull-right">
      	<button type="button" class="btn btn-success btn-xs toggle-font-size" data-size="s"><i class="icon-font-size"></i> <i class=" icon-minus2"></i></button>
      	<button type="button" class="btn btn-success btn-xs toggle-font-size" data-size="m"> <i class="icon-font-size"></i> </button>
      	<button type="button" class="btn btn-success btn-xs toggle-font-size" data-size="l"><i class="icon-font-size"></i> <i class=" icon-plus3"></i></button>
      	<button type="button" class="btn btn-success btn-xs toggle-font-size" data-size="xl"><i class="icon-font-size"></i> <i class="icon-plus3"></i><i class="icon-plus3"></i></button>
    </div>
</div>


<!-- /footer -->