<?php $__env->startSection('pageTitle'); ?> Packege <?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<div class="page-header page-header-default">
    <div class="breadcrumb-line">
        <ul class="breadcrumb">
            <li><a href="index.html"><i class="icon-home2 position-left"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="panel panel-flat">
    <div class="panel-heading">
        <h5 class="panel-title">Hotel Booking Details
        </h5>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-md-12">
                <h4>Booking Info</h4>
                <table class="table">
                    <tr>
                        <th>Check In Date</th>
                        <th>Check Out Date</th>
                        <th>Guest</th>
                        <th>Price</th>
                    </tr>
                    <tr>
                        <td><?php echo e($booking->check_in); ?></td>
                        <td><?php echo e($booking->check_out); ?></td>
                        <td><?php echo e($booking->guest); ?></td>
                        <td><?php echo e($booking->price); ?></td>
                    </tr>
                </table>
            </div>
            <div class="col-md-12">
                <h2>Hotel Details</h2>
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td>Hotel Name</td>
                            <td><?php echo e($booking->hotel->name); ?></td>
                        </tr>
                        <?php if($booking->hotel->entire_place): ?>
                        <tr>
                            <td>Entire Place :</td>
                            <td><?php echo e($booking->hotel->entire_place); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if($booking->hotel->room_details): ?>
                        <tr>
                            <td>Room Details</td>
                            <td><?php echo $booking->hotel->room_details; ?></td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td>Amenity</td>
                            <td>
                                <?php $__empty_1 = true; $__currentLoopData = $booking->hotel->amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php echo e($amenity->amenity->name . ', '); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                No Amenity Found
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php if($booking->hotel->rules): ?>
                        <tr>
                            <td>Rules</td>
                            <td><?php echo $booking->hotel->rules; ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if($booking->hotel->allow): ?>
                        <tr>
                            <td>Allow / Not allow</td>
                            <td><?php echo $booking->hotel->allow; ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if($booking->hotel->map): ?>
                        <tr>
                            <td>Map</td>
                            <td><?php echo $booking->hotel->map; ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if($booking->hotel->policy): ?>
                        <tr>
                            <td>Cancellation Policy</td>
                            <td><?php echo $booking->hotel->policy; ?></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-md-12">
                <form action="post" action="">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td>
                                    <label>Email:</label>
                                    <input type="text" id="email" class="form-control " name="email" value="<?php echo e($booking->user->email); ?>" readonly />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Messege:</label>
                                    <textarea rows="5" cols="5" class="form-control summernote" name="messege" id="messege" style="resize: none;"></textarea>
                                </td>
                            </tr>
                        </tbody>
                        <tfoot>
                        <tr>
                            <td>
                                <button type="submit" class="btn btn-info"> <i class=" icon-mail5"></i>Send Mail</button>
                                <button type="submit" class="btn btn-danger"> <i class=" icon-alarm-cancel"></i>Cancel Tour</button>
                            </td>
                        </tr>
                        </tfoot>
                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/editors/summernote/summernote.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/forms/styling/uniform.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/demo_pages/editor_summernote.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/demo_pages/form_checkboxes_radios.js')); ?>"></script>
<script src="<?php echo e(asset('backend/global_assets/js/plugins/notifications/sweet_alert.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/details.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>