<?php $__env->startSection('pageTitle'); ?> about-us <?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('page-header'); ?>
		<img src="<?php echo e(asset('/storage/pages/about/'.$aboutinfo->about_banner)); ?>" class="bg1" height="400px" />

				<div class="centered3 titleimg9">

					<h2><?php echo e($aboutinfo->abt_heading); ?></h2>				

				</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-12">
    <div class="panel panel-default">
    <div class="panel-body">
     <?php echo $aboutinfo->abt_content; ?>

    </div>
  </div>
 </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('fontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>