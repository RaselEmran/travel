<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPackege extends Model
{
	protected $with=['packege'];
    public function packege()
    {
    	return $this->belongsTo('App\Packege');
    }
}
