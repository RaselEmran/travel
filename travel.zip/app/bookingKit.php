<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bookingKit extends Model
{
    //
}
